package clases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



public class Conexion 
{
	public String driver="com.mysql.cj.jdbc.Driver";
	
	public Connection getConnection() throws ClassNotFoundException
	{
		Connection conexion=null;
		try 
		{
			Class.forName(driver);
			conexion=DriverManager.getConnection("jdbc:mysql://localhost:3306/tpfinal_alumnos","root","");
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		return conexion;
			
	}
	
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		System.out.println("Hello...");
		Connection conexion=null;
		Conexion conex=new Conexion();
		conexion=conex.getConnection();
		
		PreparedStatement ps;
		ResultSet rs;
		
		ps=conexion.prepareStatement("select * from alumnos");
		rs=ps.executeQuery();
		
		while(rs.next())
		{
			String apellido=rs.getString("apellido");
			String nombre=rs.getString("nombre");
			System.out.println(apellido+", "+nombre);
		}

	}

}
