package clases;

import java.time.LocalDate;

public class Alumnos 
{
	private int id_alumno;
	private String apellido;
	private String nombre;
	private int dni;
	private String ciudad;
	private String provincia;
	private String mail;
	private boolean estado;
	private LocalDate fecha_alta;
	
	
	//constructor
	public Alumnos(int id_alumno, String apellido, String nombre, int dni, String ciudad, String provincia, String mail,
			boolean estado, LocalDate fecha_alta) 
	{
		//super();
		this.id_alumno = id_alumno;
		this.apellido = apellido;
		this.nombre = nombre;
		this.dni = dni;
		this.ciudad = ciudad;
		this.provincia = provincia;
		this.mail = mail;
		this.estado = estado;
		this.fecha_alta = fecha_alta;
	}
	
	
	//getters y setters
	public int getId_alumno() 
	{
		return id_alumno;
	}

	public void setId_alumno(int id_alumno) 
	{
		this.id_alumno = id_alumno;
	}
	public String getApellido() 
	{
		return apellido;
	}
	public void setApellido(String apellido) 
	{
		this.apellido = apellido;
	}
	public String getNombre() 
	{
		return nombre;
	}
	public void setNombre(String nombre) 
	{
		this.nombre = nombre;
	}
	public int getDni() {
		return dni;
	}
	public void setDni(int dni) 
	{
		this.dni = dni;
	}
	public String getCiudad() 
	{
		return ciudad;
	}
	public void setCiudad(String ciudad) 
	{
		this.ciudad = ciudad;
	}
	public String getProvincia() 
	{
		return provincia;
	}
	public void setProvincia(String provincia) 
	{
		this.provincia = provincia;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) 
	{
		this.mail = mail;
	}
	public boolean isEstado() 
	{
		return estado;
	}
	public void setEstado(boolean estado) 
	{
		this.estado = estado;
	}
	public LocalDate getFecha_alta() 
	{
		return fecha_alta;
	}
	public void setFecha_alta(LocalDate fecha_alta) 
	{
		this.fecha_alta = fecha_alta;
	}
	
}

	