package clases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AlumnosDAO
	{
		
		Connection conexion=null;
		
		public AlumnosDAO() throws ClassNotFoundException
		{
			Conexion con=new Conexion();
			conexion=con.getConnection();
		}

		
		public List<Alumnos> listarAlumnos()
		{
			PreparedStatement ps;
			ResultSet rs;
			List<Alumnos> lista=new ArrayList<Alumnos>();
			
			try
			{
			ps=conexion.prepareStatement("select * from alumnos");
			rs=ps.executeQuery();
			
			while(rs.next())
			{
				int id=rs.getInt("id_alumno");
				String apellido=rs.getNString("apellido");
				String nombre=rs.getNString("nombre");
				int dni=rs.getInt("dni");
				String ciudad=rs.getNString("ciudad");
				String provincia=rs.getNString("provincia");
				String mail=rs.getNString("mail");
				boolean estado=rs.getBoolean("estado");		
				LocalDate fecha=rs.getDate("fecha_alta").toLocalDate();				
				Alumnos alumno=new Alumnos(id,apellido,nombre,dni,ciudad,provincia,mail,estado,fecha);			
				lista.add(alumno);			
			}
			return lista;
			
			}
			catch(SQLException e)
			{
				System.out.println(e);
				return null;
			}		
		}
		
		
		public boolean insertarAlumno(Alumnos alumno) 
		{
			PreparedStatement ps;		
			try
			{
				ps=conexion.prepareStatement("insert into alumnos (apellido, nombre, dni, ciudad, provincia, mail, fecha_alta, estado) values(?,?,?,?,?,?,?,?)");
				ps.setString(1, alumno.getApellido());
				ps.setString(2, alumno.getNombre());
				ps.setInt(3, alumno.getDni());
				ps.setString(4, alumno.getCiudad());
				ps.setString(5, alumno.getProvincia());				
				ps.setString(6, alumno.getMail());
				ps.setObject(7, LocalDate.now());
				ps.setBoolean(8, true);
				ps.execute();
				return true;
			}
			catch(SQLException e)
			{
				System.out.println(e);
				return false;
			}
		}
		
		public boolean actualizarAlumno(Alumnos alumno)
		{
			PreparedStatement ps;	
			try
			{
			 ps=conexion.prepareStatement("update alumnos set apellido=?, nombre=?, dni=?, ciudad=?, provincia=?, mail=? where id_alumno=?");
			 ps.setString(1, alumno.getApellido());
			 ps.setString(2, alumno.getNombre());
			 ps.setInt(3, alumno.getDni());
			 ps.setString(4, alumno.getCiudad());
			 ps.setString(5, alumno.getProvincia());
			 ps.setString(6, alumno.getMail());
			 ps.setInt(7, alumno.getId_alumno());
			 ps.execute();
			return true;		
			}
			catch(SQLException e)
			{
				System.out.println(e);
				return false;
			}		
		}
		
		
		public boolean eliminarAlumno(int _id)
		{
			PreparedStatement ps;	
			try
			{
				ps=conexion.prepareStatement("delete from alumnos where id_alumno=?");
				ps.setInt(1, _id);
				ps.execute();
				return true;
			}
			catch(SQLException e)
			{
				System.out.println(e);
				return false;
			}	
			
		}
		
		
		public Alumnos mostrarAlumno(int _id)
		{
			PreparedStatement ps;
			ResultSet rs;
			Alumnos alumno=null;
			
			
			try
			{
				ps=conexion.prepareStatement("select * from alumnos where id_alumno=?");
				ps.setInt(1, _id);
				rs=ps.executeQuery();
				
				while(rs.next())
				{
				int id=rs.getInt("id_alumno");		
				String apellido=rs.getNString("apellido");
				String nombre=rs.getNString("nombre");				
				int dni=rs.getInt("dni");
				String ciudad=rs.getNString("ciudad");
				String provincia=rs.getNString("provincia");
				String mail=rs.getNString("mail");
				boolean estado=rs.getBoolean("estado");		
				LocalDate fecha=rs.getDate("fecha_alta").toLocalDate();				
				alumno=new Alumnos(id,apellido,nombre,dni,ciudad,provincia,mail,estado,fecha);
				}
				return alumno;				
			}
			catch(SQLException e)
			{
				System.out.println(e);
				return null;
			}	
		}		
	}
